function [y,isterm,dir] = gstop(t,z,ignore)
y = z(2);
isterm = 1;
dir = -1;
